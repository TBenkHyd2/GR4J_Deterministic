function SS1 = SS1(I,C);
% HYDROGRAMME UNITAIRE LENT Matlab code By T. Benkaci
% Function calculates time delay for HU1, Aorccding to GR4J FORTRAN (CEMAGREF)
% See GR4J Model (CEMAGREF-IRSTEA)
FI = I;
    if FI <= 0., 
        SS1=0.;
    elseif FI >= C,
            SS1=1.;
    elseif FI < C,
                SS1=(FI/C)^(2.5);
    end;

    
     

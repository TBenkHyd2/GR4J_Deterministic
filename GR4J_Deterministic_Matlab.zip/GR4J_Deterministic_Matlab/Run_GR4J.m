clc, close all, clear all;
global x Nash 
% COMPILATION DU MODELE PLUIE-DEBIT-GR4J ** RAINFALL RUNOFF MODEL- GR4J  PAR_BY T. BENKACI & N. DECHEMI---
% DETERMINISTICS OPTIMISATION MMETHODS  METHODES D'OPTIMISATION DETERMINISTES 

%data=load('File_Data.txt'); % File of Data, do not change Name of this File, only copy and paste your Data
%P = data(:,1);  % First Vector : Rainfall in mm
%E = data(:,2);  % Second Vector : Evapotranspiration in mm
%Qobs=data(:,3); % Third Vector of Data  in m3/s
%param=load('parameters.txt'); % Paremters of Calibration
%Sup=param(1);  %Area of Baisn in km2
%  Bounds of Parameters : in File :   Bounds_Param.txt  
%Bounds=load('Bounds_Param.txt');%
%lb=Bounds(1:4)';
%ub=Bounds(5:8)';
% x0=load('Initial_Param.txt'); x0= x0' ;
 Optim_GR4J
 